from .regressor import piecewise
from .plotter import piecewise_plot

__all__ = ['piecewise', 'piecewise_plot']
